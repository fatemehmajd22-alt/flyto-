const API = '/api';

const cities = {
  "داخلی": ["تهران","مشهد","شیراز","اصفهان","تبریز","کیش","اهواز","یزد"],
  "خارجی": ["تهران","دبی","استانبول","آنتالیا","بانکوک","پاریس","کوالالامپور"]
};

let currentType = "داخلی";
let pendingBooking = null; 


function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2600);
}

function getToken(){ return localStorage.getItem('flyto_token'); }
function getUser(){
  try{ return JSON.parse(localStorage.getItem('flyto_user') || 'null'); }catch(e){ return null; }
}
function setSession(token, user){
  localStorage.setItem('flyto_token', token);
  localStorage.setItem('flyto_user', JSON.stringify(user));
  renderAuthArea();
}
function clearSession(){
  localStorage.removeItem('flyto_token');
  localStorage.removeItem('flyto_user');
  renderAuthArea();
}

async function api(path, opts = {}){
  const headers = Object.assign({'Content-Type':'application/json'}, opts.headers || {});
  const token = getToken();
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch(API + path, Object.assign({}, opts, {headers}));
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || 'خطایی رخ داد.');
  return data;
}

function renderAuthArea(){
  const area = document.getElementById('auth-area');
  const user = getUser();
  if (user){
    area.innerHTML = `
      <div class="user-chip">
        ${user.name}
        ${user.isAdmin ? '<a href="/admin" style="color:var(--blue-800);">پنل مدیریت</a>' : ''}
        <button class="btn small ghost" id="logout-btn">خروج</button>
      </div>`;
    document.getElementById('logout-btn').onclick = () => { clearSession(); toast('از حساب خود خارج شدید.'); };
  } else {
    area.innerHTML = `<button class="btn ghost" id="login-open-btn">ورود / عضویت</button>`;
    document.getElementById('login-open-btn').onclick = openAuthModal;
  }
}


function fillSelects(){
  const list = cities[currentType] || cities["داخلی"];
  const fromSel = document.getElementById('from');
  const toSel = document.getElementById('to');
  fromSel.innerHTML = list.map(c=>`<option>${c}</option>`).join('');
  toSel.innerHTML = list.map(c=>`<option>${c}</option>`).join('');
  toSel.selectedIndex = 1;
}

document.getElementById('tabs').addEventListener('click', (e)=>{
  const btn = e.target.closest('.tab');
  if(!btn) return;
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  btn.classList.add('active');
  currentType = btn.dataset.type;
  const isMulti = currentType === "چندمسیره";
  document.getElementById('single-search').style.display = isMulti ? 'none' : 'block';
  document.getElementById('multi-note').style.display = isMulti ? 'block' : 'none';
  document.getElementById('results').classList.remove('show');
  if(!isMulti) fillSelects();
});

document.getElementById('search-btn').addEventListener('click', runSearch);

async function runSearch(){
  const from = document.getElementById('from').value;
  const to = document.getElementById('to').value;
  const box = document.getElementById('results');

  try{
    const params = new URLSearchParams({type: currentType, from, to});
    const { flights, fallback } = await api('/flights?' + params.toString());

    box.classList.add('show');
    if (!flights.length){
      box.innerHTML = `<div class="no-result">پروازی برای این مسیر یافت نشد. لطفاً مسیر دیگری را امتحان کنید.</div>`;
      return;
    }
    box.innerHTML = (fallback ? `<div class="no-result">پروازی دقیقاً برای این مسیر ثبت نشد؛ چند گزینه مشابه را ببینید:</div>` : '') +
      flights.map(f => `
        <div class="result-row">
          <div class="result-info">
            <b>${f.origin} ✈ ${f.destination} — ${f.airline}</b>
            <span>ساعت پرواز ${f.departure_time} · مدت ${f.duration} · ${f.seats_available} صندلی باقی‌مانده</span>
          </div>
          <div class="result-price">${f.price.toLocaleString('fa-IR')} <small>تومان / هر نفر</small></div>
          <button class="book-btn" onclick="startBooking(${f.id})">انتخاب و رزرو</button>
        </div>
      `).join('');
  }catch(err){
    box.classList.add('show');
    box.innerHTML = `<div class="no-result">خطا در دریافت پروازها: ${err.message}</div>`;
  }
}




async function startBooking(flightId){
  if (!getToken()){
    toast('برای رزرو ابتدا وارد حساب کاربری خود شوید.');
    openAuthModal();
    return;
  }
  const pax = parseInt(document.getElementById('pax').value, 10) || 1;
  try{
    const booking = await api('/bookings', {
      method: 'POST',
      body: JSON.stringify({ flightId, passengers: pax })
    });
    const flightRes = await api('/flights/' + flightId);
    pendingBooking = { bookingId: booking.id, total: booking.total_price, flight: flightRes };
    openPaymentModal();
  }catch(err){
    toast('خطا در ثبت رزرو: ' + err.message);
  }
}

function openPaymentModal(){
  const summary = document.getElementById('payment-summary');
  const f = pendingBooking.flight;
  summary.innerHTML = `
    <b>${f.origin} ✈ ${f.destination} — ${f.airline}</b>
    مبلغ قابل پرداخت: ${pendingBooking.total.toLocaleString('fa-IR')} تومان
  `;
  document.getElementById('payment-error').classList.remove('show');
  document.getElementById('payment-form').reset();
  document.getElementById('payment-modal').classList.add('show');
}
document.getElementById('payment-close-btn').onclick = () => {
  document.getElementById('payment-modal').classList.remove('show');
};

document.getElementById('payment-form').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const errBox = document.getElementById('payment-error');
  errBox.classList.remove('show');
  try{
    const result = await api(`/bookings/${pendingBooking.bookingId}/pay`, {
      method:'POST',
      body: JSON.stringify({
        cardHolder: document.getElementById('pay-name').value,
        cardNumber: document.getElementById('pay-card').value,
        expiry: document.getElementById('pay-expiry').value,
        cvv: document.getElementById('pay-cvv').value
      })
    });
    document.getElementById('payment-modal').classList.remove('show');
    toast(`پرداخت موفق ✅ کد پیگیری: ${result.transactionRef}`);
    document.getElementById('results').classList.remove('show');
  }catch(err){
    errBox.textContent = err.message;
    errBox.classList.add('show');
  }
});




function openAuthModal(){
  document.getElementById('auth-modal').classList.add('show');
  showLoginView();
}
document.getElementById('auth-close-btn').onclick = () => {
  document.getElementById('auth-modal').classList.remove('show');
};

function showLoginView(){
  document.getElementById('login-view').style.display = 'block';
  document.getElementById('register-view').style.display = 'none';
}
function showRegisterView(){
  document.getElementById('login-view').style.display = 'none';
  document.getElementById('register-view').style.display = 'block';
}
document.getElementById('go-register').onclick = (e)=>{ e.preventDefault(); showRegisterView(); };
document.getElementById('go-login').onclick = (e)=>{ e.preventDefault(); showLoginView(); };

document.getElementById('login-form').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const errBox = document.getElementById('login-error');
  errBox.classList.remove('show');
  try{
    const { token, user } = await api('/auth/login', {
      method:'POST',
      body: JSON.stringify({
        email: document.getElementById('login-email').value,
        password: document.getElementById('login-password').value
      })
    });
    setSession(token, user);
    document.getElementById('auth-modal').classList.remove('show');
    toast(`خوش آمدید ${user.name} 👋`);
  }catch(err){
    errBox.textContent = err.message;
    errBox.classList.add('show');
  }
});

document.getElementById('register-form').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const errBox = document.getElementById('register-error');
  errBox.classList.remove('show');
  try{
    const { token, user } = await api('/auth/register', {
      method:'POST',
      body: JSON.stringify({
        name: document.getElementById('register-name').value,
        email: document.getElementById('register-email').value,
        password: document.getElementById('register-password').value
      })
    });
    setSession(token, user);
    document.getElementById('auth-modal').classList.remove('show');
    toast(`ثبت‌نام با موفقیت انجام شد 🎉 خوش آمدید ${user.name}`);
  }catch(err){
    errBox.textContent = err.message;
    errBox.classList.add('show');
  }
});



const detailContent = {
  'svc-flights': {
    eyebrow: 'خدمات ما',
    title: 'رزرو پرواز داخلی و خارجی',
    body: `
      <p>با flyto به راحتی می‌توانید بلیط پرواز‌های داخلی و خارجی را از میان معتبرترین ایرلاین‌های کشور و جهان جستجو، مقایسه و رزرو کنید.</p>
      <ul>
        <li>جستجوی هم‌زمان ده‌ها مسیر پروازی داخلی و خارجی</li>
        <li>مقایسه قیمت و زمان‌بندی پروازهای مختلف</li>
        <li>امکان انتخاب پرواز رفت و برگشت</li>
        <li>صدور آنی بلیط پس از پرداخت موفق</li>
      </ul>`
  },
  'svc-baggage': {
    eyebrow: 'خدمات ما',
    title: 'بار و خدمات اضافی',
    body: `
      <p>اگر حجم بار سفرتان بیشتر از سهمیه استاندارد بلیط است، می‌توانید پیش از پرواز نسبت به خرید بار اضافه یا خدمات ویژه اقدام کنید تا در فرودگاه با هزینه و دردسر اضافه مواجه نشوید.</p>
      <ul>
        <li>خرید بار اضافه با نرخ ارزان‌تر نسبت به فرودگاه</li>
        <li>رزرو صندلی با فضای پای بیشتر</li>
        <li>سفارش وعده غذایی ویژه در پرواز</li>
      </ul>`
  },
  'svc-insurance': {
    eyebrow: 'خدمات ما',
    title: 'بیمه مسافرتی',
    body: `
      <p>پیش از هر سفر خارجی، تهیه بیمه مسافرتی معتبر یکی از الزامات ورود به بسیاری از کشورهاست. flyto امکان خرید انواع بیمه‌های مسافرتی با پوشش‌های متنوع را برای شما فراهم کرده است.</p>
      <ul>
        <li>پوشش هزینه‌های درمانی و بستری در خارج از کشور</li>
        <li>پوشش خسارت گم‌شدن یا تاخیر بار</li>
        <li>پوشش لغو یا تاخیر پرواز</li>
        <li>صدور بیمه‌نامه به‌صورت آنی و قابل ارائه به سفارت</li>
      </ul>`
  },
  'svc-hotel': {
    eyebrow: 'خدمات ما',
    title: 'رزرو هتل',
    body: `
      <p>در کنار رزرو پرواز، می‌توانید اقامتگاه مورد نظر خود را نیز در مقصد رزرو کنید؛ از هتل‌های اقتصادی گرفته تا اقامتگاه‌های لوکس در بهترین نقاط شهر.</p>
      <ul>
        <li>دسترسی به هزاران هتل در سراسر جهان</li>
        <li>فیلتر بر اساس قیمت، ستاره و امکانات</li>
        <li>امکان لغو رزرو رایگان در بسیاری از هتل‌ها</li>
      </ul>`
  },
  'svc-car': {
    eyebrow: 'خدمات ما',
    title: 'اجاره خودرو',
    body: `
      <p>برای جابه‌جایی راحت‌تر در مقصد سفر، می‌توانید پیش از سفر یا بلافاصله پس از فرود، خودروی مورد نظر خود را با شرایط آسان اجاره کنید.</p>
      <ul>
        <li>تحویل خودرو در فرودگاه مقصد</li>
        <li>امکان انتخاب خودروهای اقتصادی تا لوکس</li>
        <li>بیمه کامل شخص ثالث و بدنه</li>
      </ul>`
  },
  'dest-dubai': {
    eyebrow: 'مقصد محبوب',
    title: 'دبی',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Burj%20al%20Arab%20(2392511901).jpg?width=800',
    body: `
      <p>دبی، شهری مدرن در امارات متحده عربی، ترکیبی از برج‌های سربه‌فلک‌کشیده، مراکز خرید بزرگ و سواحل زیبای خلیج فارس است. این مقصد برای سفرهای کوتاه تفریحی و خرید بسیار محبوب است.</p>
      <ul>
        <li>پرواز مستقیم از تهران با مدت حدود ۲ ساعت</li>
        <li>جاذبه‌های مشهور: برج خلیفه، برج العرب، پارک‌های آبی</li>
        <li>بهترین فصل سفر: پاییز تا بهار</li>
      </ul>`
  },
  'dest-istanbul': {
    eyebrow: 'مقصد محبوب',
    title: 'استانبول',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Sultan%20Ahmed%20Mosque%20-%20Blue%20Mosque%20-%20Istanbul%2C%20Turkey%20%2810582551665%29.jpg?width=800',
    body: `
      <p>استانبول، تنها شهر جهان که در دو قاره آسیا و اروپا قرار دارد، ترکیبی از تاریخ، فرهنگ و زندگی مدرن است و یکی از پرطرفدارترین مقاصد گردشگری برای مسافران ایرانی محسوب می‌شود.</p>
      <ul>
        <li>پرواز مستقیم از تهران با مدت حدود ۳ ساعت</li>
        <li>جاذبه‌های مشهور: مسجد آیاصوفیه، کاخ توپکاپی، بازار بزرگ</li>
        <li>بهترین فصل سفر: بهار و پاییز</li>
      </ul>`
  },
  'dest-antalya': {
    eyebrow: 'مقصد محبوب',
    title: 'آنتالیا',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Kemer%20beach%2C%20Antalya.jpg?width=800',
    body: `
      <p>آنتالیا در سواحل جنوبی ترکیه، به‌خاطر سواحل شنی، آب‌وهوای مدیترانه‌ای و هتل‌های آل‌اینکلوسیو، مقصدی محبوب برای سفرهای تفریحی و خانوادگی است.</p>
      <ul>
        <li>پرواز مستقیم از تهران با مدت حدود ۳ ساعت</li>
        <li>جاذبه‌های مشهور: شهر قدیم کالئیچی، آبشار دودن</li>
        <li>بهترین فصل سفر: تابستان</li>
      </ul>`
  },
  'dest-bangkok': {
    eyebrow: 'مقصد محبوب',
    title: 'بانکوک',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Wat%20Arun%20from%20Chao%20Phraya%20River%20at%20sunset.jpg?width=800',
    body: `
      <p>بانکوک، پایتخت تایلند، شهری پرجنب‌وجوش با معابد باستانی، بازارهای شناور و زندگی شبانه پویاست؛ مقصدی مناسب برای سفرهای فرهنگی و ماجراجویانه.</p>
      <ul>
        <li>پرواز از تهران با مدت حدود ۷ تا ۸ ساعت</li>
        <li>جاذبه‌های مشهور: معبد وات آرون، بازار شناور، کاخ سلطنتی</li>
        <li>بهترین فصل سفر: آذر تا اسفند</li>
      </ul>`
  },
  'dest-paris': {
    eyebrow: 'مقصد محبوب',
    title: 'پاریس',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Tour%20Eiffel%20Wikimedia%20Commons.jpg?width=800',
    body: `
      <p>پاریس، پایتخت فرانسه و شهر عشق، با برج ایفل، موزه لوور و خیابان‌های تاریخی، یکی از رویاپردازانه‌ترین مقاصد گردشگری اروپا برای مسافران ایرانی است.</p>
      <ul>
        <li>پرواز از تهران با مدت حدود ۶ تا ۷ ساعت</li>
        <li>جاذبه‌های مشهور: برج ایفل، موزه لوور، کلیسای نوتردام</li>
        <li>بهترین فصل سفر: بهار و تابستان</li>
      </ul>`
  }
};

function openDetail(key){
  const data = detailContent[key];
  if (!data) return;
  document.getElementById('detail-eyebrow').textContent = data.eyebrow || '';
  document.getElementById('detail-title').textContent = data.title || '';
  document.getElementById('detail-body').innerHTML = data.body || '';
  const imgBox = document.getElementById('detail-img');
  if (data.img){
    imgBox.style.display = 'block';
    imgBox.innerHTML = `<img src="${data.img}" alt="${data.title}">`;
  } else {
    imgBox.style.display = 'none';
    imgBox.innerHTML = '';
  }
  document.getElementById('detail-modal').classList.add('show');
}
document.getElementById('detail-close-btn').onclick = () => {
  document.getElementById('detail-modal').classList.remove('show');
};
document.querySelectorAll('[data-detail]').forEach(card => {
  card.addEventListener('click', () => openDetail(card.dataset.detail));
});




document.getElementById('newsletter-form').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const emailInput = document.getElementById('newsletter-email');
  try{
    await api('/newsletter', { method:'POST', body: JSON.stringify({ email: emailInput.value }) });
    toast('عضویت شما با موفقیت ثبت شد 🎉');
    emailInput.value = '';
  }catch(err){
    toast('خطا در ثبت عضویت: ' + err.message);
  }
});




function jDiv(a, b) { return ~~(a / b); }
function jMod(a, b) { return a - ~~(a / b) * b; }

function jalCal(jy) {
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  const bl = breaks.length;
  const gy = jy + 621;
  let leapJ = -14, jp = breaks[0], jm, jump, leap, n, i;
  for (i = 1; i < bl; i += 1) {
    jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + jDiv(jump, 33) * 8 + jDiv(jMod(jump, 33), 4);
    jp = jm;
  }
  n = jy - jp;
  leapJ = leapJ + jDiv(n, 33) * 8 + jDiv(jMod(n, 33) + 3, 4);
  if (jMod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = jDiv(gy, 4) - jDiv((jDiv(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + jDiv(jump + 4, 33) * 33;
  leap = jMod(jMod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}

function g2d(gy, gm, gd) {
  let d = jDiv((gy + jDiv(gm - 8, 6) + 100100) * 1461, 4) + jDiv(153 * jMod(gm + 9, 12) + 2, 5) + gd - 34840408;
  d = d - jDiv(jDiv(gy + 100100 + jDiv(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn) {
  let j = 4 * jdn + 139361631;
  j = j + jDiv(jDiv(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = jDiv(jMod(j, 1461), 4) * 5 + 308;
  const gd = jDiv(jMod(i, 153), 5) + 1;
  const gm = jMod(jDiv(i, 153), 12) + 1;
  const gy = jDiv(j, 1461) - 100100 + jDiv(8 - gm, 6);
  return { gy, gm, gd };
}

function j2d(jy, jm, jd) {
  const r = jalCal(jy);
  return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - jDiv(jm, 7) * (jm - 7) + jd - 1;
}

function d2j(jdn) {
  const gy = d2g(jdn).gy;
  let jy = gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let jd, jm, k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) {
      jm = 1 + jDiv(k, 31);
      jd = jMod(k, 31) + 1;
      return { jy, jm, jd };
    }
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  jm = 7 + jDiv(k, 30);
  jd = jMod(k, 30) + 1;
  return { jy, jm, jd };
}

function toJalali(gy, gm, gd) { return d2j(g2d(gy, gm, gd)); }
function toGregorian(jy, jm, jd) { return d2g(j2d(jy, jm, jd)); }
function isLeapJalaliYear(jy) { return jalCal(jy).leap === 1; }
function jalaliMonthLength(jy, jm) {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalaliYear(jy) ? 30 : 29;
}

const faDigits = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
function toFa(n){ return String(n).replace(/[0-9]/g, d => faDigits[d]); }
function pad2(n){ return String(n).padStart(2,'0'); }
const jalaliMonths = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
const jalaliWeekdays = ['ش','ی','د','س','چ','پ','ج'];

function initJalaliCalendar(){
  const dateInput = document.getElementById('date');
  const box = document.getElementById('date-box');
  const panel = document.getElementById('jalali-calendar');
  if (!dateInput || !panel) return;

  const now = new Date();
  const today = toJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
  const state = { jy: today.jy, jm: today.jm, selJy: null, selJm: null, selJd: null };

  function setSelectedDate(jy, jm, jd){
    state.selJy = jy; state.selJm = jm; state.selJd = jd;
    dateInput.value = `${toFa(jy)}/${toFa(pad2(jm))}/${toFa(pad2(jd))}`;
    const g = toGregorian(jy, jm, jd);
    dateInput.dataset.iso = `${g.gy}-${pad2(g.gm)}-${pad2(g.gd)}`;
  }

  function renderCalendar(){
    const { jy, jm } = state;
    const len = jalaliMonthLength(jy, jm);
    const firstG = toGregorian(jy, jm, 1);
    const firstDow = (new Date(firstG.gy, firstG.gm - 1, firstG.gd).getDay() + 1) % 7;

    let daysHtml = '';
    for (let i = 0; i < firstDow; i++) daysHtml += `<div class="jc-day empty"></div>`;
    for (let d = 1; d <= len; d++) {
      const isToday = jy === today.jy && jm === today.jm && d === today.jd;
      const isSel = jy === state.selJy && jm === state.selJm && d === state.selJd;
      daysHtml += `<div class="jc-day${isToday ? ' today' : ''}${isSel ? ' selected' : ''}" data-d="${d}">${toFa(d)}</div>`;
    }

    panel.innerHTML = `
      <div class="jc-header">
        <button type="button" class="jc-nav" id="jc-prev">›</button>
        <b>${jalaliMonths[jm - 1]} ${toFa(jy)}</b>
        <button type="button" class="jc-nav" id="jc-next">‹</button>
      </div>
      <div class="jc-weekdays">${jalaliWeekdays.map(w => `<span>${w}</span>`).join('')}</div>
      <div class="jc-days">${daysHtml}</div>
      <div class="jc-footer"><button type="button" class="jc-today-btn" id="jc-today">امروز</button></div>
    `;

    panel.querySelectorAll('.jc-day[data-d]').forEach(el => {
      el.addEventListener('click', () => {
        setSelectedDate(jy, jm, parseInt(el.dataset.d, 10));
        panel.classList.remove('show');
        renderCalendar();
      });
    });
    panel.querySelector('#jc-prev').addEventListener('click', () => {
      state.jm -= 1;
      if (state.jm < 1) { state.jm = 12; state.jy -= 1; }
      renderCalendar();
    });
    panel.querySelector('#jc-next').addEventListener('click', () => {
      state.jm += 1;
      if (state.jm > 12) { state.jm = 1; state.jy += 1; }
      renderCalendar();
    });
    panel.querySelector('#jc-today').addEventListener('click', () => {
      state.jy = today.jy; state.jm = today.jm;
      setSelectedDate(today.jy, today.jm, today.jd);
      panel.classList.remove('show');
      renderCalendar();
    });
  }

  box.addEventListener('click', (e) => {
    e.stopPropagation();
    panel.classList.toggle('show');
  });
  document.addEventListener('click', (e) => {
    if (!panel.contains(e.target) && !box.contains(e.target)) panel.classList.remove('show');
  });

  renderCalendar();
}



fillSelects();
renderAuthArea();
initJalaliCalendar();
