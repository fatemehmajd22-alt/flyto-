const API = '/api';

function getToken(){ return localStorage.getItem('flyto_token'); }
function getUser(){
  try{ return JSON.parse(localStorage.getItem('flyto_user') || 'null'); }catch(e){ return null; }
}
function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2600);
}


function parseSqlDate(s){
  return new Date(s.replace(' ', 'T') + 'Z');
}

async function api(path, opts = {}){
  const headers = Object.assign({'Content-Type':'application/json'}, opts.headers || {});
  const token = getToken();
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch(API + path, Object.assign({}, opts, {headers}));
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || 'خطایی رخ داد.');
  return data;
}

const user = getUser();
if (!getToken() || !user || !user.isAdmin){
  document.getElementById('gate').style.display = 'block';
} else {
  document.getElementById('admin-app').style.display = 'block';
  document.getElementById('admin-name').textContent = user.name;
  document.getElementById('admin-logout').onclick = () => {
    localStorage.removeItem('flyto_token');
    localStorage.removeItem('flyto_user');
    window.location.href = '/';
  };
  initAdmin();
}

document.querySelectorAll('.admin-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.admin-tab').forEach(t=>t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(tab.dataset.panel).classList.add('active');
  });
});

async function initAdmin(){
  await loadSummary();
  await loadFlights();
  await loadBookings();
  await loadUsers();

  document.getElementById('flight-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try{
      await api('/admin/flights', {
        method:'POST',
        body: JSON.stringify({
          type: document.getElementById('f-type').value,
          origin: document.getElementById('f-origin').value,
          destination: document.getElementById('f-destination').value,
          airline: document.getElementById('f-airline').value,
          departure_time: document.getElementById('f-time').value,
          duration: document.getElementById('f-duration').value,
          price: parseInt(document.getElementById('f-price').value, 10),
          seats_available: parseInt(document.getElementById('f-seats').value, 10) || 20
        })
      });
      toast('پرواز با موفقیت اضافه شد.');
      e.target.reset();
      loadFlights();
      loadSummary();

    }catch(err){
      toast('خطا: ' + err.message);
    }
  });

}



async function loadSummary(){
  const s = await api('/admin/summary');
  document.getElementById('summary-grid').innerHTML = `
    <div class="summary-card"><b>${s.flights}</b><span>تعداد پروازها</span></div>
    <div class="summary-card"><b>${s.users}</b><span>تعداد کاربران</span></div>
    <div class="summary-card"><b>${s.bookings}</b><span>تعداد رزروها</span></div>
    <div class="summary-card"><b>${s.revenue.toLocaleString('fa-IR')}</b><span>درآمد (تومان)</span></div>
  `;

}


async function loadFlights(){
  const flights = await api('/admin/flights');
  document.querySelector('#flights-table tbody').innerHTML = flights.map(f => `
    <tr>
      <td>${f.id}</td>
      <td>${f.type}</td>
      <td>${f.origin} → ${f.destination}</td>
      <td>${f.airline}</td>
      <td>${f.departure_time}</td>
      <td>${f.price.toLocaleString('fa-IR')}</td>
      <td>${f.seats_available}</td>
      <td class="row-actions"><button class="btn small danger" onclick="deleteFlight(${f.id})">حذف</button></td>
    </tr>
  `).join('');
}



async function deleteFlight(id){
  if (!confirm('آیا از حذف این پرواز مطمئن هستید؟')) return;
  try{
    await api('/admin/flights/' + id, { method:'DELETE' });
    toast('پرواز حذف شد.');
    loadFlights();
    loadSummary();
  }catch(err){
    toast('خطا: ' + err.message);
  }
}

async function loadBookings(){
  const bookings = await api('/admin/bookings');
  document.querySelector('#bookings-table tbody').innerHTML = bookings.map(b => `
    <tr>
      <td>${b.id}</td>
      <td>${b.user_name}<br><small style="color:var(--muted)">${b.user_email}</small></td>
      <td>${b.origin} → ${b.destination} (${b.airline})</td>
      <td>${b.passengers}</td>
      <td>${b.total_price.toLocaleString('fa-IR')}</td>
      <td>${statusLabel(b.status)}</td>
      <td>${parseSqlDate(b.created_at).toLocaleDateString('fa-IR')}</td>
    </tr>
  `).join('');

}



function statusLabel(s){
  return { pending: 'در انتظار پرداخت', paid: 'پرداخت‌شده', cancelled: 'لغو‌شده' }[s] || s;
}

async function loadUsers(){
  const users = await api('/admin/users');
  document.querySelector('#users-table tbody').innerHTML = users.map(u => `
    <tr>
      <td>${u.id}</td>
      <td>${u.name}</td>
      <td>${u.email}</td>
      <td>${u.is_admin ? 'مدیر' : 'کاربر'}</td>
      <td>${parseSqlDate(u.created_at).toLocaleDateString('fa-IR')}</td>
    </tr>
  `).join('');
}
