const jwt = require('jsonwebtoken');

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: 'ورود الزامی است. لطفاً ابتدا وارد شوید.' });
  }
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'نشست شما منقضی شده است. دوباره وارد شوید.' });
  }
}

function requireAdmin(req, res, next) {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ error: 'دسترسی غیرمجاز. این بخش مخصوص مدیران است.' });
  }
  next();
}

module.exports = { requireAuth, requireAdmin };
