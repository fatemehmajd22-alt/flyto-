const express = require('express');
const db = require('../db/database');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireAdmin);

// --- Dashboard summary ---
router.get('/summary', (req, res) => {
  const flights = db.prepare('SELECT COUNT(*) c FROM flights').get().c;
  const users = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  const bookings = db.prepare('SELECT COUNT(*) c FROM bookings').get().c;
  const revenue = db.prepare(`SELECT COALESCE(SUM(amount),0) s FROM payments WHERE status = 'success'`).get().s;
  res.json({ flights, users, bookings, revenue });
});

// --- Flights CRUD ---
router.get('/flights', (req, res) => {
  res.json(db.prepare('SELECT * FROM flights ORDER BY id DESC').all());
});

router.post('/flights', (req, res) => {
  const { type, origin, destination, airline, departure_time, duration, price, seats_available } = req.body;
  if (!type || !origin || !destination || !airline || !departure_time || !duration || !price) {
    return res.status(400).json({ error: 'همه فیلدهای پرواز الزامی است.' });
  }
  const info = db.prepare(`
    INSERT INTO flights (type, origin, destination, airline, departure_time, duration, price, seats_available)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(type, origin, destination, airline, departure_time, duration, price, seats_available || 20);
  res.status(201).json(db.prepare('SELECT * FROM flights WHERE id = ?').get(info.lastInsertRowid));
});

router.put('/flights/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM flights WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'پرواز یافت نشد.' });

  const merged = { ...existing, ...req.body };
  db.prepare(`
    UPDATE flights SET type=?, origin=?, destination=?, airline=?, departure_time=?, duration=?, price=?, seats_available=?
    WHERE id = ?
  `).run(merged.type, merged.origin, merged.destination, merged.airline, merged.departure_time,
    merged.duration, merged.price, merged.seats_available, req.params.id);

  res.json(db.prepare('SELECT * FROM flights WHERE id = ?').get(req.params.id));
});

router.delete('/flights/:id', (req, res) => {
  const info = db.prepare('DELETE FROM flights WHERE id = ?').run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'پرواز یافت نشد.' });
  res.json({ success: true });
});

// --- Bookings (read-only) ---
router.get('/bookings', (req, res) => {
  const rows = db.prepare(`
    SELECT b.*, u.name AS user_name, u.email AS user_email,
           f.origin, f.destination, f.airline
    FROM bookings b
    JOIN users u ON u.id = b.user_id
    JOIN flights f ON f.id = b.flight_id
    ORDER BY b.created_at DESC
  `).all();
  res.json(rows);
});

// --- Users (read-only) ---
router.get('/users', (req, res) => {
  res.json(db.prepare('SELECT id, name, email, is_admin, created_at FROM users ORDER BY id DESC').all());
});

module.exports = router;
