const express = require('express');
const crypto = require('crypto');
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Create a pending booking
// NOTE: seats are reserved (decremented) right here, atomically with the
// availability check. Booking-creation and payment are two separate HTTP
// requests, so if we only *checked* availability here and decremented later
// at payment time (as the previous version did), several users could each
// pass the check for the same last seat and all successfully pay for it
// (overselling). Reserving the seat immediately closes that gap.
const createBooking = db.transaction((userId, flightId, pax) => {
  const flight = db.prepare('SELECT * FROM flights WHERE id = ?').get(flightId);
  if (!flight) {
    const err = new Error('پرواز یافت نشد.');
    err.status = 404;
    throw err;
  }
  if (flight.seats_available < pax) {
    const err = new Error('ظرفیت کافی برای این پرواز وجود ندارد.');
    err.status = 409;
    throw err;
  }

  db.prepare('UPDATE flights SET seats_available = seats_available - ? WHERE id = ?').run(pax, flight.id);

  const total = flight.price * pax;
  const info = db.prepare(`
    INSERT INTO bookings (user_id, flight_id, passengers, total_price, status)
    VALUES (?, ?, ?, ?, 'pending')
  `).run(userId, flight.id, pax, total);

  return db.prepare('SELECT * FROM bookings WHERE id = ?').get(info.lastInsertRowid);
});

router.post('/', requireAuth, (req, res) => {
  const { flightId, passengers } = req.body;
  const pax = Math.max(1, parseInt(passengers, 10) || 1);

  try {
    const booking = createBooking(req.user.id, flightId, pax);
    res.status(201).json(booking);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message || 'خطا در ثبت رزرو.' });
  }
});

// List current user's bookings
router.get('/me', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT b.*, f.origin, f.destination, f.airline, f.departure_time, f.type
    FROM bookings b JOIN flights f ON f.id = b.flight_id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
  `).all(req.user.id);
  res.json(rows);
});

// Mock payment gateway checkout for a booking
router.post('/:id/pay', requireAuth, (req, res) => {
  const booking = db.prepare('SELECT * FROM bookings WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user.id);
  if (!booking) return res.status(404).json({ error: 'رزرو یافت نشد.' });
  if (booking.status === 'paid') return res.status(409).json({ error: 'این رزرو قبلاً پرداخت شده است.' });

  const { cardNumber, cardHolder, expiry, cvv } = req.body;
  if (!cardNumber || !expiry || !cvv) {
    return res.status(400).json({ error: 'اطلاعات کارت ناقص است.' });
  }
  // Basic mock validation (this is NOT a real payment gateway)
  const digits = String(cardNumber).replace(/\s/g, '');
  if (digits.length < 16) {
    return res.status(400).json({ error: 'شماره کارت نامعتبر است.' });
  }

  const txnRef = 'FLYTO-' + crypto.randomBytes(6).toString('hex').toUpperCase();

  const runPayment = db.transaction(() => {
    db.prepare(`
      INSERT INTO payments (booking_id, amount, method, status, transaction_ref)
      VALUES (?, ?, 'card', 'success', ?)
    `).run(booking.id, booking.total_price, txnRef);

    db.prepare(`UPDATE bookings SET status = 'paid' WHERE id = ?`).run(booking.id);

    // Seats were already reserved (decremented) when the booking was
    // created, so payment does not touch seats_available again.
  });
  runPayment();

  res.json({ success: true, transactionRef: txnRef, bookingId: booking.id, amount: booking.total_price });
});

module.exports = router;
