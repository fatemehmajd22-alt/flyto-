const express = require('express');
const db = require('../db/database');

const router = express.Router();

router.post('/', (req, res) => {
  const { email } = req.body;
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
    return res.status(400).json({ error: 'ایمیل معتبر وارد کنید.' });
  }
  db.prepare('INSERT INTO newsletter (email) VALUES (?)').run(email.toLowerCase());
  res.status(201).json({ success: true });
});

module.exports = router;
