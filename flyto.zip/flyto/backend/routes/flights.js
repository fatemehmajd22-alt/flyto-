const express = require('express');
const db = require('../db/database');

const router = express.Router();

// GET /api/flights?type=داخلی&from=تهران&to=مشهد
router.get('/', (req, res) => {
  const { type, from, to } = req.query;

  let query = 'SELECT * FROM flights WHERE 1=1';
  const params = [];

  if (type) {
    query += ' AND type = ?';
    params.push(type);
  }
  if (from) {
    query += ' AND origin = ?';
    params.push(from);
  }
  if (to) {
    query += ' AND destination = ?';
    params.push(to);
  }

  let flights = db.prepare(query).all(...params);

  // Fallback: if no exact match, suggest a few flights of the same type
  let fallback = false;
  if (flights.length === 0 && type) {
    flights = db.prepare('SELECT * FROM flights WHERE type = ? LIMIT 3').all(type);
    fallback = true;
  }

  res.json({ flights, fallback });
});

// GET /api/flights/cities?type=داخلی -> distinct origin/destination list
router.get('/cities', (req, res) => {
  const { type } = req.query;
  const rows = db.prepare(
    'SELECT DISTINCT origin AS city FROM flights WHERE type = ? UNION SELECT DISTINCT destination AS city FROM flights WHERE type = ?'
  ).all(type || 'داخلی', type || 'داخلی');
  res.json({ cities: rows.map((r) => r.city) });
});

router.get('/:id', (req, res) => {
  const flight = db.prepare('SELECT * FROM flights WHERE id = ?').get(req.params.id);
  if (!flight) return res.status(404).json({ error: 'پرواز یافت نشد.' });
  res.json(flight);
});

module.exports = router;
