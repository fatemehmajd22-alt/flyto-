require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');

const initDb = require('./db/init');
initDb(); 


const authRoutes = require('./routes/auth');
const flightRoutes = require('./routes/flights');
const bookingRoutes = require('./routes/bookings');
const adminRoutes = require('./routes/admin');
const newsletterRoutes = require('./routes/newsletter');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());



app.use('/api/auth', authRoutes);
app.use('/api/flights', flightRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/newsletter', newsletterRoutes);


const frontendPath = path.join(__dirname, '..', 'frontend');
app.use(express.static(frontendPath));

app.get('/admin', (req, res) => {
  res.sendFile(path.join(frontendPath, 'admin.html'));
});

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Not found' });
  }
  res.sendFile(path.join(frontendPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`flyto server running at http://localhost:${PORT}`);
});
