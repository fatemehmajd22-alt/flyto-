require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./database');

function createSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      is_admin INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS flights (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,               -- داخلی | خارجی
      origin TEXT NOT NULL,
      destination TEXT NOT NULL,
      airline TEXT NOT NULL,
      departure_time TEXT NOT NULL,
      duration TEXT NOT NULL,
      price INTEGER NOT NULL,
      seats_available INTEGER NOT NULL DEFAULT 20,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      flight_id INTEGER NOT NULL REFERENCES flights(id) ON DELETE CASCADE,
      passengers INTEGER NOT NULL DEFAULT 1,
      total_price INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',  -- pending | paid | cancelled
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
      amount INTEGER NOT NULL,
      method TEXT NOT NULL DEFAULT 'card',
      status TEXT NOT NULL DEFAULT 'success',   -- success | failed
      transaction_ref TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS newsletter (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
}

function seedFlights() {
  const count = db.prepare('SELECT COUNT(*) AS c FROM flights').get().c;
  if (count > 0) return;

  const seed = [
    { type: 'داخلی', origin: 'تهران', destination: 'مشهد', airline: 'ایران‌ایر', departure_time: '07:30', duration: '1h 20m', price: 2450000 },
    { type: 'داخلی', origin: 'تهران', destination: 'شیراز', airline: 'ماهان', departure_time: '09:15', duration: '1h 40m', price: 2150000 },
    { type: 'داخلی', origin: 'مشهد', destination: 'تهران', airline: 'آسمان', departure_time: '14:00', duration: '1h 20m', price: 2300000 },
    { type: 'داخلی', origin: 'تهران', destination: 'کیش', airline: 'قشم‌ایر', departure_time: '11:45', duration: '2h 00m', price: 3100000 },
    { type: 'داخلی', origin: 'اصفهان', destination: 'تهران', airline: 'زاگرس', departure_time: '16:20', duration: '1h 00m', price: 1950000 },
    { type: 'داخلی', origin: 'تهران', destination: 'تبریز', airline: 'ایران‌ایر', departure_time: '08:10', duration: '1h 15m', price: 2600000 },
    { type: 'خارجی', origin: 'تهران', destination: 'دبی', airline: 'ماهان', departure_time: '06:00', duration: '2h 00m', price: 4850000 },
    { type: 'خارجی', origin: 'تهران', destination: 'استانبول', airline: 'ترکیش‌ایرلاینز', departure_time: '10:30', duration: '3h 10m', price: 3750000 },
    { type: 'خارجی', origin: 'تهران', destination: 'آنتالیا', airline: 'پگاسوس', departure_time: '13:15', duration: '3h 00m', price: 4150000 },
    { type: 'خارجی', origin: 'تهران', destination: 'بانکوک', airline: 'قطر ایرویز', departure_time: '23:40', duration: '7h 30m', price: 8950000 },
    { type: 'خارجی', origin: 'تهران', destination: 'پاریس', airline: 'ایرفرانس', departure_time: '02:15', duration: '6h 45m', price: 11500000 },
    { type: 'خارجی', origin: 'مشهد', destination: 'دبی', airline: 'فلای‌دبی', departure_time: '05:30', duration: '2h 10m', price: 5200000 }
  ];

  const insert = db.prepare(`
    INSERT INTO flights (type, origin, destination, airline, departure_time, duration, price)
    VALUES (@type, @origin, @destination, @airline, @departure_time, @duration, @price)
  `);
  const insertMany = db.transaction((rows) => rows.forEach((r) => insert.run(r)));
  insertMany(seed);
  console.log(`Seeded ${seed.length} flights.`);
}

function seedAdmin() {
  const email = process.env.ADMIN_EMAIL || 'admin@flyto.ir';
  const password = process.env.ADMIN_PASSWORD || 'Admin@12345';
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return;

  const hash = bcrypt.hashSync(password, 10);
  db.prepare(`
    INSERT INTO users (name, email, password_hash, is_admin)
    VALUES (?, ?, ?, 1)
  `).run('flyto Admin', email, hash);
  console.log(`Seeded admin user: ${email} (password from .env)`);
}

function init() {
  createSchema();
  seedFlights();
  seedAdmin();
}

if (require.main === module) {
  init();
  console.log('Database initialized at db/flyto.sqlite');
}

module.exports = init;
