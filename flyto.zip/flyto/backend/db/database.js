const path = require('path');

let DatabaseSync;
try {
  ({ DatabaseSync } = require('node:sqlite'));
} catch (err) {
  console.error(
    '\nخطا: ماژول داخلی node:sqlite در دسترس نیست.\n' +
    'این پروژه از SQLite داخلی Node.js استفاده می‌کند و به Node.js نسخه 22.5.0 یا بالاتر نیاز دارد ' +
    '(نسخه پیشنهادی: 22.13+ یا 24+). لطفاً Node.js خود را به‌روزرسانی کنید و دوباره تلاش کنید.\n'
  );
  throw err;
}

const DB_PATH = path.join(__dirname, 'flyto.sqlite');

const raw = new DatabaseSync(DB_PATH);
raw.exec('PRAGMA journal_mode = WAL');
raw.exec('PRAGMA foreign_keys = ON');




const db = {
  exec: (sql) => raw.exec(sql),

  prepare: (sql) => {
    const stmt = raw.prepare(sql);
    return {
      run: (...params) => stmt.run(...params),
      get: (...params) => stmt.get(...params),
      all: (...params) => stmt.all(...params),
    };
  },

  transaction: (fn) => {
    return (...args) => {
      raw.exec('BEGIN');
      try {
        const result = fn(...args);
        raw.exec('COMMIT');
        return result;
      } catch (err) {
        try { raw.exec('ROLLBACK'); } catch (_) { /* ignore */ }
        throw err;
      }
    };
  },
};

module.exports = db;
